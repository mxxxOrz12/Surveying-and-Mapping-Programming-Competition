﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 对流层改正_练习1
{
    class Station
    {
        public string name;
        public int t;//年积日
        public string T;//年月日
        public double L;//经度
        public double B;//纬度
        public double H;//大地高
        public double E;//高度角
        public double sin_E;
        public double ZHD;
        public double mw;//湿分量
        public double md;//干分量
        public double deta_S;//对流层延迟
    }
}
